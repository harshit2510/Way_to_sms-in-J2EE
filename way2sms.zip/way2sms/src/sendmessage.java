
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;
/**
 * Servlet implementation class sendmessage
 */
@WebServlet("/sendmessage")
public class sendmessage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public sendmessage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		try
		{
			
		String str1=request.getParameter("ms");
		String str2=request.getParameter("id");

		Class.forName("com.mysql.jdbc.Driver");
		Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/way2sms2?user=root&password=adminadmin");	
	
		if(str1.equals("Group Message"))
		{
		
			
			   String str="select * from groupp where id='"+str2+"'";
			    PreparedStatement st=cn.prepareStatement(str);
			   ResultSet rs=st.executeQuery();
			  String data="";
			  
			   while(rs.next()){
				   data=data+"<option>"+rs.getString(2)+"</option>";
			   }
			   
			   
				   
				pw.println(data);
			   
			
			
			
			
			
			
			
		}
		if(str1.equals("General Message"))
		{
			
			String str="select * from contact1 where id='"+str2+"'";
		    PreparedStatement st=cn.prepareStatement(str);
		   ResultSet rs=st.executeQuery();
		  String data="";
		  
		   while(rs.next()){
			   
			   data=data+"<option>"+rs.getString(3)+"("+rs.getString(4)+")</option>";
		   }
		   
		   
			   
			pw.println(data);
		   
			
			
			
			
		}
			
		
			
			
			
			
			
			
			
			
			
			
			
		}
	catch(Exception e)
		{
		pw.println(e.getMessage());
		
		
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
