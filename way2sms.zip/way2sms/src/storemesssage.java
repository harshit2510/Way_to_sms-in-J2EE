

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class storemesssage
 */
@WebServlet("/storemesssage")
public class storemesssage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public storemesssage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter pw=response.getWriter();
		
		try
		{
			String str1=request.getParameter("ms");
			String str2=request.getParameter("to");
			String str3=request.getParameter("id");

			Class.forName("com.mysql.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/way2sms2?user=root&password=adminadmin");	
		
					   
			   
     		String str6="Insert into msg values(?,?,?)";
			    		  PreparedStatement st1=cn.prepareStatement(str6);
			    		  st1.setString(1,str1);
			    		  st1.setString(2,str2); 
			    		  st1.setString(3,str3);
			    		 
			    		  st1.executeUpdate();
			    		  pw.println("success");
			    		  
			    		  response.sendRedirect("sent.jsp?msg="+str1+"&to="+str2);
			    	
			    	
			    	
			    	
			    	
			    }
			   
			
			
			
			
			
			
			
			
			
			
			
		
	catch(Exception e)
		{
		pw.println(e.getMessage());
		
		
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
