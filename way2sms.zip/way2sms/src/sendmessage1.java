

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class sendmessage1
 */
@WebServlet("/sendmessage1")
public class sendmessage1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public sendmessage1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		try
		{
			
		String str1=request.getParameter("ms");
		String str2=request.getParameter("id");
		String str3=request.getParameter("to");

		Class.forName("com.mysql.jdbc.Driver");
		Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/way2sms2?user=root&password=adminadmin");	
	
		if(str1.equals("Group Message"))
		{
		
			
			   String str="select * from contact1 where id='"+str2+"'";
			    PreparedStatement st=cn.prepareStatement(str);
			   ResultSet rs=st.executeQuery();
			  String data="";
			  
			   while(rs.next()){
				   if(rs.getString(2).equals(str3))
				   {	   
			   
					   data=data+rs.getString(4)+",";
			   }
			   }
			   
			   
				   
				pw.println(data);
			   
			
			
			
			
			
			
			
		}
		
		else
		{
			String c=str3.substring(str3.indexOf('(')+1,(str3.length()-1));
			String data="";
			data=data+c+",";
			pw.println(data);
		}
			
			
		
		}
		catch(Exception e)
		{
		pw.println(e.getMessage());
		
		
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
