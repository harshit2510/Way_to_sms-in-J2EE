
import java.sql.*;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Aftersignup
 */
@WebServlet("/Aftersignup")
public class Aftersignup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Aftersignup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		
		try
		{
			String str1=request.getParameter("id");
			String str2=request.getParameter("pass");
			String str3=request.getParameter("name");
			String str4=request.getParameter("phone");
			String str5=request.getParameter("email");
			Class.forName("com.mysql.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/way2sms2?user=root&password=adminadmin");	
		
		
			int f=0;
			   String str="Select * from login";
			    PreparedStatement st=cn.prepareStatement(str);
			    ResultSet rs=st.executeQuery();
			    while(rs.next())
			    {
			    	if(rs.getString(1).equals(str1))
			    	{
			    		f=1;
			    		pw.println("failure");
			    		break;
			    		
			    	}
			    }
			    	if(f==0)
			    	{
			    		String str6="Insert into login values(?,?,?,?,?)";
			    		  PreparedStatement st1=cn.prepareStatement(str6);
			    		  st1.setString(1,str1);
			    		  st1.setString(2,str2); 
			    		  st1.setString(3,str3);
			    		  st1.setString(4,str4);
			    		  st1.setString(5,str5);
			    		  st1.executeUpdate();
			    		  pw.println("success");
			    		  
			    	
			    	
			    	
			    	
			    	
			    	
			    }
			   
			
			
			
			
			
			
			
			
			
			
			
		}
	catch(Exception e)
		{
		pw.println(e.getMessage());
		
		
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
